const { chromium } = require('playwright');

(async () => {
  try {
    console.log('Launching browser');
    const browser = await chromium.launch({ headless: false });
    console.log('Browser launched');
    const page = await browser.newPage();
    await page.goto('https://www.amazon.com/');
    console.log('Amazon homepage loaded');
    await browser.close();
    console.log('Browser closed');
  } catch (error) {
    console.error('Error in basic launch test:', error);
  }
})();
