const { chromium } = require('playwright');
const axios = require('axios');

const proxyAPI = 'https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&country=us&proxy_format=protocolipport&format=text&timeout=2000';

async function getProxies() {
  try {
    const response = await axios.get(proxyAPI);
    const proxyList = response.data.split('\n').filter(proxy => proxy.trim() !== '');
    console.log('Proxies fetched:', proxyList.length);
    return proxyList.map(proxy => {
      const [ip, port] = proxy.split(':');
      return { ip, port: parseInt(port, 10) };
    }).filter(proxy => proxy.ip && !isNaN(proxy.port)); // Filter out invalid entries
  } catch (error) {
    console.error('Error fetching proxies:', error);
    return [];
  }
}

(async () => {
  const proxies = await getProxies();
  if (proxies.length === 0) {
    console.error('No proxies available. Exiting...');
    return;
  }

  const proxy = proxies[0]; // Use the first proxy for testing
  console.log(`Using proxy: http://${proxy.ip}:${proxy.port}`);

  try {
    console.log('Launching browser with proxy');
    const browser = await chromium.launch({
      headless: false,
      proxy: { server: `http://${proxy.ip}:${proxy.port}` }
    });
    console.log('Browser launched');
    const page = await browser.newPage();
    await page.goto('https://www.amazon.com/');
    console.log('Amazon homepage loaded');
    await browser.close();
    console.log('Browser closed');
  } catch (error) {
    console.error('Error in proxy launch test:', error);
  }
})();
