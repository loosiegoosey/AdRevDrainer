const { chromium } = require('playwright');
const axios = require('axios');
const { getProxyForUrl } = require('proxy-chain');

const proxyAPI = 'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=yes&anonymity=elite&simplified=true';
const proxyRefreshInterval = 30 * 60 * 1000; // Refresh proxies every 30 minutes
let proxies = [];

async function fetchProxies() {
  try {
    const response = await axios.get(proxyAPI);
    proxies = response.data.split('\r\n').filter(Boolean);
    console.log(`Fetched ${proxies.length} proxies`);
  } catch (error) {
    console.error('Error fetching proxies:', error);
  }
}

async function rotateProxy(proxy) {
  try {
    return await getProxyForUrl(`http://${proxy}`);
  } catch (error) {
    console.error('Error creating proxy URL:', error);
    return null;
  }
}

async function clickAds(browser, proxy) {
  console.log(`Using proxy: ${proxy}`);
  
  let context, page;

  try {
    const proxyUrl = await rotateProxy(proxy);
    if (!proxyUrl) throw new Error('Invalid proxy URL');
    
    context = await browser.newContext({
      proxy: { server: proxyUrl },
    });
    page = await context.newPage();

    await page.goto('https://www.amazon.com/', { waitUntil: 'networkidle' });

    // Identify and click on ads
    const adSelectors = [
      'iframe[name*="ad"]',
      'iframe[src*="adsystem"]',
      'iframe[src*="doubleclick"]'
    ];

    for (const selector of adSelectors) {
      const frames = page.frames();
      for (const frame of frames) {
        const adFrame = await frame.waitForSelector(selector, { timeout: 10000 }).catch(() => null);
        if (adFrame) {
          const adLink = await adFrame.$('a').catch(() => null);
          if (adLink) {
            await adLink.click();
            console.log('Ad clicked');
            return; // Return after successfully clicking an ad
          }
        }
      }
    }
  } catch (error) {
    console.error('Error during ad clicking:', error);
  } finally {
    if (context) {
      await context.close();
    }
  }
}

(async () => {
  const internalIp = await import('internal-ip'); // Dynamic import for ESM module
  const localIP = await internalIp.internalIpV4();
  console.log('Local IP:', localIP);

  await fetchProxies();
  setInterval(fetchProxies, proxyRefreshInterval);

  const browser = await chromium.launch({ headless: false });
  console.log('Browser launched');

  let proxyIndex = 0;

  while (true) {
    if (proxies.length === 0) {
      console.error('No proxies available. Waiting for proxy refresh...');
      await new Promise(resolve => setTimeout(resolve, 60000)); // Wait 1 minute before retrying
      continue;
    }

    const proxy = proxies[proxyIndex];
    await clickAds(browser, proxy);

    proxyIndex = (proxyIndex + 1) % proxies.length; // Rotate to the next proxy

    // Random delay between switching proxies to further mimic human behavior
    await new Promise(resolve => setTimeout(resolve, Math.random() * 5000 + 2000)); // Random delay between 2-7 seconds
  }

  await browser.close();
})();
