# AmazonAdRevDrainer
 Automated Ad Clicker to Drain Ad Revenue
